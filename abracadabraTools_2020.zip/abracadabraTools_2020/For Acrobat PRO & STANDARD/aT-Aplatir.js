////////////////////////////////////////////////////////////////////////////////////////////////////
//
// abracadabraTools DC - Flatten/Aplatir
// Version 2020-02-20
//
////////////////////////---ENGLISH---////////////////////////
//
// abracadabraTools-Flatten flattens all comments and all fields into a PDF document
// abracadabraTools-Flatten is available into the Edit:abracadabraTools menu and as a Quicktool icon
// abracadabraTools-Flatten requires Acrobat Pro or Acrobat Standard, version X(10) or +
//
// abracadabraTools DC is a set of free utilities created by abracadabraPDF.net
// abracadabraTools DC adds many useful functions into Adobe Acrobat DC
// abracadabraTools DC runs with Mac OS and Windows
// Copyrights - JR Boulay - 2002-2020 - https://www.abracadabrapdf.net/contact/
// Support & assistance : https://abracadabrapdf.net/forum/index.php/board,15.0.html
//
////////////////////////---FRANÇAIS---////////////////////////
//
// abracadabraTools-Flatten aplatit tous les commentaires et tous les champs de formulaire dans le document PDF actif
// abracadabraTools-Flatten est disponible dans le menu Edition:abracadabraTools et comme icône d'outil rapide
// abracadabraTools-Flatten requiert Acrobat Pro ou Acrobat Standard, version X(10) ou +
//
// abracadabraTools DC est un ensemble d'utilitaires gratuits offert par abracadabraPDF.net
// abracadabraTools DC ajoute des fonctions utiles dans le logiciel Adobe Acrobat DC
// abracadabraTools DC fonctionne sur systèmes Mac OS et Windows
// Tous droits réservés - JR Boulay - 2002-2020 - https://www.abracadabrapdf.net/contact/
// Support & assistance : https://abracadabrapdf.net/forum/index.php/board,15.0.html
//
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
//
if (typeof app.formsVersion != "undefined" && app.formsVersion > 9 && app.viewerVariation != "Reader") {
	var strTitreId = "abracadabraTools DC";
	if (app.language == "FRA") {
		var apla0 = "Aplatir";
		var apla1 = "Aplatir les commentaires et les champs de formulaires";
		var apla2 = "Toutes les pages";
		var apla3 = "Page active uniquement";
		var cMessAplatissDoc = "APLATIR\r\r\rVoulez-vous vraiment aplatir toutes les pages de ce document ?\r\rC'est-\u00E0-dire incruster et figer tous les champs de formulaire et tous les commentaires dans les fonds de pages.\r\rCette op\u00E9ration ne pourra pas \u00EAtre annul\u00E9e.\rSi besoin utilisez : menu Fichier : R\u00E9tablir.\r";
		var cMessAplatissPag = "APLATIR\r\r\rVoulez-vous vraiment aplatir la page active de ce document ?\r\rC'est-\u00E0-dire incruster et figer tous les champs de formulaire et tous les commentaires dans le fond de page.\r\rCette op\u00E9ration ne pourra pas \u00EAtre annul\u00E9e.\rSi besoin utilisez : menu Fichier : R\u00E9tablir.\r";
	}
	else {	
		var apla0 = "Flatten";
		var apla1 = "Flatten form fields and annots on PDF pages";
		var apla2 = "All pages";
		var apla3 = "Current page";
		var cMessAplatissDoc = "FLATTEN\r\r\rDo you really want to flatten all form fields and all comments so they become part of the document content?\r\rThis action cannot be canceled.\rIf necessary use : File menu : Revert.\r";
		var cMessAplatissPag = "FLATTEN\r\r\rDo you really want to flatten all form fields and all comments so they become part of the current page content?\r\rThis action cannot be canceled.\rIf necessary use : File menu : Revert.\r";
	}
}
//
////////////////////////////////////////////////////////////////////////////////////////////////////
if(void 0!==app.formsVersion&&app.formsVersion>9&&"Reader"!=app.viewerVariation){var strNomMenu="abracadabraTools \u002A";1!=global.aTmenu&&(app.addSubMenu({cName:strNomMenu,cParent:"Edit",nPos:0}),app.addMenuItem({cName:"-",cParent:"Edit",nPos:0,cEnable:!1,cExec:null}),global.aTmenu=1),app.addSubMenu({cName:apla0,cParent:strNomMenu,nPos:0}),app.addMenuItem({cName:apla2,cParent:apla0,nPos:0,cEnable:"event.rc = event.target != null",cExec:"myTrustedAplatirDoc(aplatirDoc)"}),app.addMenuItem({cName:"-",cParent:apla0,nPos:1,cEnable:!1,cExec:null}),app.addMenuItem({cName:apla3,cParent:apla0,nPos:2,cEnable:"event.rc = event.target != null",cExec:"myTrustedAplatirPage(aplatirPage)"});var strIconFlatbouton="ffffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffff",oIconFlatbouton={count:0,width:20,height:20,read:function(f){return strIconFlatbouton.slice(this.count,this.count+=f)}},flatBouton={cName:"flatDoc",cExec:"aplatirDepuisIcone()",cEnable:"event.rc = event.target != null",cMarked:"event.rc = false",cTooltext:apla1,oIcon:oIconFlatbouton,cLabel:apla0};try{app.removeToolButton("flatDoc")}catch(f){}try{app.addToolButton(flatBouton)}catch(f){}function aplatirDepuisIcone(){null!=this.event.target&&(documentCible=this,choix=app.popUpMenuEx({cName:apla2,bEnabled:!0},{cName:"-",bEnabled:!1},{cName:apla3,bEnabled:!0}),choix&&(choix==apla2&&myTrustedAplatirDoc(aplatirDoc),choix==apla3&&myTrustedAplatirPage(aplatirPage)))}function aplatirDoc(){app.beginPriv();try{if("undefined"==typeof bAffichAlerteAplatir&&(bAffichAlerteAplatir=!0),bAffichAlerteAplatir){var f={bInitialValue:!0,bAfterValue:!1};4==app.alert({cMsg:cMessAplatissDoc,cTitle:strTitreId,oCheckbox:f,nIcon:2,nType:2})&&(bAffichAlerteAplatir=!f.bAfterValue,this.flattenPages(),app.beep())}else this.flattenPages(),app.beep()}catch(f){console.println(f),console.show()}app.endPriv()}var myTrustedAplatirDoc=app.trustedFunction(aplatirDoc);function aplatirPage(){app.beginPriv();try{if("undefined"==typeof bAffichAlerteAplatir&&(bAffichAlerteAplatir=!0),bAffichAlerteAplatir){var f={bInitialValue:!0,bAfterValue:!1};4==app.alert({cMsg:cMessAplatissPag,cTitle:strTitreId,oCheckbox:f,nIcon:2,nType:2})&&(bAffichAlerteAplatir=!f.bAfterValue,this.flattenPages(this.pageNum),app.beep())}else this.flattenPages(this.pageNum),app.beep()}catch(f){console.println(f),console.show()}app.endPriv()}var myTrustedAplatirPage=app.trustedFunction(aplatirPage);if(1!=global.aTmenAide){if("FRA"==app.language)var strMenAide00="abracadabraTools",strMenAide01="Support & assistance...",strMenAide02="Actualisation...",strMenAide03="https://www.abracadabrapdf.net/?p=111",strMenAide04="Site web",strMenAide05="https://www.abracadabrapdf.net/";else strMenAide00="abracadabraTools",strMenAide01="Support & Assistance...",strMenAide02="Check for update...",strMenAide03="https://www.abracadabrapdf.net/?p=972",strMenAide04="Web Site",strMenAide05="https://www.abracadabrapdf.net/?p=1591";app.addMenuItem({cName:"-",cParent:"Help",nPos:21,cEnable:!1,cExec:null}),app.addSubMenu({cName:strMenAide00,cParent:"Help",nPos:22}),app.addMenuItem({cName:strMenAide04,cParent:strMenAide00,nPos:0,cExec:"app.launchURL(strMenAide05);"}),app.addMenuItem({cName:strMenAide02,cParent:strMenAide00,nPos:1,cExec:"app.launchURL(strMenAide03);"}),app.addMenuItem({cName:strMenAide01,cParent:strMenAide00,nPos:2,cExec:"app.launchURL('https://abracadabrapdf.net/forum/');"}),global.aTmenAide=1}}
////////////////////////////////////////////////////////////////////////////////////////////////////
