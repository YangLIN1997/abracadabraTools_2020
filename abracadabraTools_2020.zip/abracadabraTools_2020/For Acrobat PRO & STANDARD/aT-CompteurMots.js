////////////////////////////////////////////////////////////////////////////////////////////////////
//
// abracadabraTools DC - Compteur de mot / Word counter
// Version 2020-02-20
//
////////////////////////---ENGLISH---////////////////////////
//
// abracadabraTools-CompteurMots counts all words in a page or in the whole PDF document
// abracadabraTools-CompteurMots is available into the Edit:abracadabraTools menu and as a Quicktool icon
// abracadabraTools-CompteurMots runs with Acrobat Reader, Acrobat Pro and Acrobat Standard, version X(10) or +
// abracadabraTools-CompteurMots is available in six languages (German, English, Spanish, French, Italian and Swedish, automatically selected)
//
// abracadabraTools DC is a set of free utilities created by abracadabraPDF.net
// abracadabraTools DC adds many useful functions into Adobe Acrobat DC
// abracadabraTools DC runs with Mac OS and Windows
// Copyrights - JR Boulay - 2002-2020 - https://www.abracadabrapdf.net/contact/
// Support & assistance : https://abracadabrapdf.net/forum/index.php/board,15.0.html
//
////////////////////////---FRANÇAIS---////////////////////////
//
// abracadabraTools-CompteurMots compte tous les mots d'une page ou d'un document PDF entier
// abracadabraTools-CompteurMots est disponible dans le menu Edition:abracadabraTools et comme icône d'outil rapide
// abracadabraTools-CompteurMots fonctionne avec Acrobat Reader, Acrobat Pro et Acrobat Standard, version X(10) ou +
// abracadabraTools-CompteurMots est disponible en six langues (Allemand, Anglais, Espagnol, Français, Italien et Suédois, sélection automatique)
//
// abracadabraTools DC est un ensemble d'utilitaires gratuits offert par abracadabraPDF.net
// abracadabraTools DC ajoute des fonctions utiles dans le logiciel Adobe Acrobat DC
// abracadabraTools DC fonctionne sur systèmes Mac OS et Windows
// Tous droits réservés - JR Boulay - 2002-2020 - https://www.abracadabrapdf.net/contact/
// Support & assistance : https://abracadabrapdf.net/forum/index.php/board,15.0.html
//
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
//
if (typeof app.formsVersion != "undefined" && app.formsVersion > 9) {
	var strTitreId = "abracadabraTools DC";
	if (app.language == "FRA") {
		var comptalert1 ="Il y a ";
		var comptalert21 = " mot(s) dans cette page.";
		var comptalert22 = " mot(s) dans ce document.";
		var comptalert222 = "Soit une moyenne de ";
		var comptalert223 = " mot(s) par page.";
		var comptalert33 = "Analyse de la page ";
		var abra11 = "Page active";
		var abra12 = "Document";
		var abra20 = "Compteur de mots";
		var abra20c = "COMPTEUR DE MOTS";
		var abra20b ="Compter les mots du document";
		var aboutAlert = "";
		var abra60 = "A propos";
		var abra60b = "A propos des abracadabraTools DC";
	}
	else if (app.language == "DEU") {
		var abra11 = "Aktuelle Seite...";
		var abra12 = "Dokument...";
		var abra20 = "Wortz\u00E4hler";
		var abra20c = "Wortz\u00E4hler";
		var abra60 = "\u00DCber...";
		var comptalert1 = "";
		var comptalert21 = " Worte auf dieser Seite.";
		var comptalert22 = " Worte in diesem Dokument.";
		var comptalert33 = "Processing page ";
		var comptalert222 = "Durchschnitt: ";
		var comptalert223 = " Worte\/Seite.";
		var abra20b = "Document word counter";
		var aboutAlert = "Deutsche \u00DCbersetzung: Thomas Tempelmann";
		var abra60 = "About";
		var abra60b = "About abracadabraTools DC";
		}
	else if (app.language == "SVE") {
		var abra11 = "Aktuell sida...";
		var abra12 = "Dokument...";
		var abra20 = "Ordr\u00E4knare";
		var abra20c = "Ordr\u00E4knare";
		var abra60 = "Om...";
		var comptalert1 = "";
		var comptalert21 = " ord p\u00E5 denna sida.";
		var comptalert22 = " ord i detta dokument.";
		var comptalert33 = "Processing page ";
		var comptalert222 = "Genomsnitt: ";
		var comptalert223 = " ord\/sida.";
		var abra20b = "Document word counter";
		var aboutAlert = "Svensk \u00F6vers\u00E4ttning av Lennart T\u00F6rnquist";
		var abra60 = "About";
		var abra60b = "About abracadabraTools DC";
		}
	else if (app.language == "ITA") {
		var abra11 = "Pagina corrente...";
		var abra12 = "Documento...";
		var abra20 = "Conta parole";
		var abra20c = "CONTA PAROLE";
		var abra60 = "Informazioni...";
		var comptalert1 = "";
		var comptalert21 = " parole in questa pagina.";
		var comptalert22 = " parole in questo documento.";
		var comptalert33 = "Processing page ";
		var comptalert222 = "Media: ";
		var comptalert223 = " parole\/pagina.";
		var abra20b = "Conta parole in questo documento";
		var aboutAlert = "Traduzione italiana di Michele Guastella";
		var abra60 = "About";
		var abra60b = "About abracadabraTools DC";
		}
	else if (app.language == "ESP") {
		var abra11 = "P\u00E1gina actual...";
		var abra12 = "Documento...";
		var abra20 = "Contador de palabras";
		var abra20c = "CONTADOR DE PALABRAS";
		var abra60 = "Sobre...";
		var comptalert1 = "";
		var comptalert21 = " palabra(s) en esta p\u00E1gina.";
		var comptalert22 = " palabra(s) en este documento.";
		var comptalert33 = "Processing page ";
		var comptalert222 = "Promedio: ";
		var comptalert223 = " palabra(s)\/p\u00E1gina.";
		var abra20b = "Contador de palabra(s) en este documento.";
		var aboutAlert = "Traducido al Espa\u00F1ol por Cecilia Wacholder";
		var abra60 = "About";
		var abra60b = "About abracadabraTools DC";
		}
	else {	
		var comptalert1 ="";
		var comptalert21 = " word(s) in this page.";
		var comptalert22 = " word(s) in this document.";
		var comptalert222 = "Average of ";
		var comptalert223 = " mot(s) per page.";
		var comptalert33 = "Processing page ";
		var abra11 = "Current Page";
		var abra12 = "Document";
		var abra20 = "Word Counter";
		var abra20c = "WORD COUNTER";
		var abra20b = "Document word counter";
		var aboutAlert = "";
		var abra60 = "About";
		var abra60b = "About abracadabraTools DC";
	}
}
//
////////////////////////////////////////////////////////////////////////////////////////////////////
if(void 0!==app.formsVersion&&app.formsVersion>9){var strNomMenu="abracadabraTools \u002A";1!=global.aTmenu&&(app.addSubMenu({cName:strNomMenu,cParent:"Edit",nPos:0}),app.addMenuItem({cName:"-",cParent:"Edit",nPos:0,cEnable:!1,cExec:null}),global.aTmenu=1),app.addSubMenu({cName:abra20,cParent:strNomMenu,nPos:0}),app.addMenuItem({cName:abra12,cParent:abra20,nPos:0,cEnable:"event.rc = event.target != null",cExec:"myTrustedDocumentWordCount(documentWordCount)"}),app.addMenuItem({cName:"-",cParent:abra20,nPos:1,cEnable:!1,cExec:null}),app.addMenuItem({cName:abra11,cParent:abra20,nPos:2,cEnable:"event.rc = event.target != null",cExec:"myTrustedPageWordCount(pageWordCount)"});var strIconComptbouton="ffffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffff",oIconComptbouton={count:0,width:20,height:20,read:function(f){return strIconComptbouton.slice(this.count,this.count+=f)}},comptBouton={cName:"comptMots",cExec:"myTrustedWordCount(WordCount)",cEnable:"event.rc = event.target != null",cMarked:"event.rc = false",cTooltext:abra20b,oIcon:oIconComptbouton,cLabel:abra20};try{app.removeToolButton("comptMots")}catch(f){}try{app.addToolButton(comptBouton)}catch(f){}function WordCount(){app.beginPriv(),null!=this.event.target&&(choix=app.popUpMenuEx({cName:abra12,bEnabled:!0},{cName:"-",bEnabled:!1},{cName:abra11,bEnabled:!0}),choix&&(choix==abra12&&myTrustedDocumentWordCount(documentWordCount),choix==abra11&&myTrustedPageWordCount(pageWordCount))),app.endPriv()}var myTrustedWordCount=app.trustedFunction(WordCount);function documentWordCount(){app.beginPriv();var f=app.thermometer;f.duration=this.numPages,f.begin();for(var a=0,e=0;e<this.numPages&&(f.value=e,f.text=comptalert33+(e+1),a+=this.getPageNumWords(e),!f.cancelled);e++);f.end(),moyenne=Math.floor(a/this.numPages),app.alert({cMsg:abra20c+"\r\r\r"+comptalert1+a+comptalert22+"\r"+comptalert222+moyenne+comptalert223+"\r",cTitle:strTitreId,nIcon:3}),cMessage1="",cMessage2=comptalert1+a+comptalert22,cMessage3=comptalert222+moyenne+comptalert223,cMessage4=aboutAlert,app.endPriv()}var myTrustedDocumentWordCount=app.trustedFunction(documentWordCount);function pageWordCount(){app.beginPriv();var f,a=0;f=this.pageNum,a+=this.getPageNumWords(f),app.alert({cMsg:abra20c+"\r\r\r"+comptalert1+a+comptalert21+"\r",cTitle:strTitreId,nIcon:3}),cMessage1="",cMessage2=comptalert1+a+comptalert21,cMessage3="",cMessage4=aboutAlert,app.endPriv()}var myTrustedPageWordCount=app.trustedFunction(pageWordCount);if(1!=global.aTmenAide){if("FRA"==app.language)var strMenAide00="abracadabraTools",strMenAide01="Support & assistance...",strMenAide02="Actualisation...",strMenAide03="https://www.abracadabrapdf.net/?p=111",strMenAide04="Site web",strMenAide05="https://www.abracadabrapdf.net/";else strMenAide00="abracadabraTools",strMenAide01="Support & Assistance...",strMenAide02="Check for update...",strMenAide03="https://www.abracadabrapdf.net/?p=972",strMenAide04="Web Site",strMenAide05="https://www.abracadabrapdf.net/?p=1591";app.addMenuItem({cName:"-",cParent:"Help",nPos:21,cEnable:!1,cExec:null}),app.addSubMenu({cName:strMenAide00,cParent:"Help",nPos:22}),app.addMenuItem({cName:strMenAide04,cParent:strMenAide00,nPos:0,cExec:"app.launchURL(strMenAide05);"}),app.addMenuItem({cName:strMenAide02,cParent:strMenAide00,nPos:1,cExec:"app.launchURL(strMenAide03);"}),app.addMenuItem({cName:strMenAide01,cParent:strMenAide00,nPos:2,cExec:"app.launchURL('https://abracadabrapdf.net/forum/');"}),global.aTmenAide=1}}
////////////////////////////////////////////////////////////////////////////////////////////////////
