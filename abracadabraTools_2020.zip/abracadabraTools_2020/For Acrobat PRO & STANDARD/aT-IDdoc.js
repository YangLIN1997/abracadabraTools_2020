////////////////////////////////////////////////////////////////////////////////////////////////////
//
// abracadabraTools DC - DocID
// Version 2020-02-20
//
////////////////////////---ENGLISH---////////////////////////
//
// abracadabraTools-DocID displays the Permanent identifier [ID] of PDF files
// abracadabraTools-DocID is available into the Edit:abracadabraTools menu and as a Quicktool icon
// abracadabraTools-DocID runs with Acrobat Reader, Acrobat Pro and Acrobat Standard, version X(10) or +
//
// abracadabraTools DC is a set of free utilities created by abracadabraPDF.net
// abracadabraTools DC adds many useful functions into Adobe Acrobat DC
// abracadabraTools DC runs with Mac OS and Windows
// Copyrights - JR Boulay - 2002-2020 - https://www.abracadabrapdf.net/contact/
// Support & assistance : https://abracadabrapdf.net/forum/index.php/board,15.0.html
//
////////////////////////---FRANÇAIS---////////////////////////
//
// abracadabraTools-DocID affiche l'identifiant permanent [ID] des documents PDF
// abracadabraTools-DocID est disponible dans le menu Edition:abracadabraTools et comme icône d'outil rapide
// abracadabraTools-DocID fonctionne avec Acrobat Reader, Acrobat Pro et Acrobat Standard, version X(10) ou +
//
// abracadabraTools DC est un ensemble d'utilitaires gratuits offert par abracadabraPDF.net
// abracadabraTools DC ajoute des fonctions utiles dans le logiciel Adobe Acrobat DC
// abracadabraTools DC fonctionne sur systèmes Mac OS et Windows
// Tous droits réservés - JR Boulay - 2002-2020 - https://www.abracadabrapdf.net/contact/
// Support & assistance : https://abracadabrapdf.net/forum/index.php/board,15.0.html
//
////////////////////////////////////////////////////////////////////////////////////////////////////
//
if (typeof app.formsVersion != "undefined" && app.formsVersion > 9) {
	var strTitreId = "abracadabraTools DC";
	if (app.language == "FRA") {
		var idStrMenu = "Identifiant permanent"; // pour menu
		var idStrMenu2 = "Identifiant"; // pour bouton
		var idTexte1 = "Le num\u00E9ro unique d'identification [ID] de ce document est :"
		var idTexte2 = "Num\u00E9ro unique d'identification du document [ID]";
		var alertInfo = "IDENTIFIANT PERMANENT\r\r\rLa premi\u00E8re partie du num\u00E9ro, \u00E0 gauche de la virgule, est le num\u00E9ro unique d\'identification du fichier PDF. Il est attribu\u00E9 une seule fois, au moment de la cr\u00E9ation du fichier.\r\rLa deuxi\u00E8me partie du num\u00E9ro, \u00E0 droite de la virgule, est le num\u00E9ro unique d\'identification de chaque variante du fichier PDF. Il est attribu\u00E9, et donc modifi\u00E9, \u00E0 chaque Enregistrer ou Enregistrer-sous effectu\u00E9 depuis un logiciel lecteur de PDF.\rLes copies ou duplications du fichier effectu\u00E9es via le syst\u00E8me d\'exploitation de l\'ordinateur n\'affectent pas ce num\u00E9ro.\r\rLa comparaison de ce num\u00E9ro unique d\'identification entre plusieurs fichiers PDF permet donc de savoir imm\u00E9diatement si ce sont exactement les m\u00EAmes, pas du tout les m\u00EAmes, ou bien si ce sont des variantes.\r\rLa fen\u00EAtre suivante autorise le copier-coller...";
	}
	else {
		var idStrMenu = "Permanent Identifier"; // pour menu
		var idStrMenu2 = "Identifier"; // pour bouton
		var idTexte1 = "Permanent identifier [ID] of this document is:";
		var idTexte2 = "Document permanent identifier [ID]";
		var alertInfo = "PERMANENT IDENTIFIER\r\r\rThe first string is a permanent identifier based on the contents of the file at the time it was originally created, it does not change when the file is incrementally updated.\r\rThe second string is a changing identifier based on the file's contents at the time it was last updated.\r\rComparing the Permanent identifier [ID] of several PDF files quickly corroborates: exactly the same, not the same at all, or a variant.\r\rFollowing window allows copy-paste...";
	}
}
//
////////////////////////////////////////////////////////////////////////////////////////////////////
if(void 0!==app.formsVersion&&app.formsVersion>9){function showDocId(){if(app.beginPriv(),void 0===global.bShowWarning1&&(global.bShowWarning1=!0,global.bPersistWarn1=!1),global.bShowWarning1){var f={bInitialValue:!0,bAfterValue:!1};app.alert({cMsg:alertInfo,nIcon:1,oCheckbox:f,cTitle:strTitreId}),global.bShowWarning1=!f.bAfterValue}app.response({cQuestion:idTexte1,cTitle:strTitreId,cDefault:this.docID}),app.endPriv()}var myTrustedShowDocId=app.trustedFunction(showDocId),strNomMenu="abracadabraTools \u002A";1!=global.aTmenu&&(app.addSubMenu({cName:strNomMenu,cParent:"Edit",nPos:0}),app.addMenuItem({cName:"-",cParent:"Edit",nPos:0,cEnable:!1,cExec:null}),global.aTmenu=1),app.addMenuItem({cName:idStrMenu,cParent:strNomMenu,nPos:0,cEnable:"event.rc = event.target != null",cExec:"myTrustedShowDocId(showDocId)"});var strIconIDbouton="ffffffffffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffffffffffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffb40000ffffffffffffffffffb40000ffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffb40000ffffffffffffffffffb40000ffffffffffffffffffffffffffb40000ffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffb40000ffffffffffffffffffb40000ffffffffffffffffffffffffffb40000ffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffb40000ffffffffffffffffffb40000ffffffffffffffffffffffffffb40000ffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffb40000ffffffffffffffffffb40000ffffffffffffffffffffffffffb40000ffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffb40000ffffffffffffffffffb40000ffffffffffffffffffffffffffb40000ffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffb40000ffffffffffffffffffb40000ffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffffffffffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffffffff",oIconIDbouton={count:0,width:20,height:20,read:function(f){return strIconIDbouton.slice(this.count,this.count+=f)}},IDbouton={cName:"DocID",cExec:"myTrustedShowDocId(showDocId)",cEnable:"event.rc = event.target != null",cMarked:"event.rc = false",cTooltext:idTexte2,oIcon:oIconIDbouton,cLabel:idStrMenu2};try{app.removeToolButton("DocID")}catch(f){}try{app.addToolButton(IDbouton)}catch(f){}if(1!=global.aTmenAide){if("FRA"==app.language)var strMenAide00="abracadabraTools",strMenAide01="Support & assistance...",strMenAide02="Actualisation...",strMenAide03="https://www.abracadabrapdf.net/?p=111",strMenAide04="Site web",strMenAide05="https://www.abracadabrapdf.net/";else strMenAide00="abracadabraTools",strMenAide01="Support & Assistance...",strMenAide02="Check for update...",strMenAide03="https://www.abracadabrapdf.net/?p=972",strMenAide04="Web Site",strMenAide05="https://www.abracadabrapdf.net/?p=1591";app.addMenuItem({cName:"-",cParent:"Help",nPos:21,cEnable:!1,cExec:null}),app.addSubMenu({cName:strMenAide00,cParent:"Help",nPos:22}),app.addMenuItem({cName:strMenAide04,cParent:strMenAide00,nPos:0,cExec:"app.launchURL(strMenAide05);"}),app.addMenuItem({cName:strMenAide02,cParent:strMenAide00,nPos:1,cExec:"app.launchURL(strMenAide03);"}),app.addMenuItem({cName:strMenAide01,cParent:strMenAide00,nPos:2,cExec:"app.launchURL('https://abracadabrapdf.net/forum/');"}),global.aTmenAide=1}}
//////////////////////////////////////////////////////////////////////////////////////////////////////
