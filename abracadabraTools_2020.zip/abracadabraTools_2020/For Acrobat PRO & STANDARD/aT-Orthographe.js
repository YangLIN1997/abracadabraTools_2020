////////////////////////////////////////////////////////////////////////////////////////////////////
//
// abracadabraTools DC - Vérifier l'orthographe / Spell Check
// Version 2020-02-20
//
////////////////////////---ENGLISH---////////////////////////
//
// abracadabra-Orthographe checks the spelling of all the words in the document
// abracadabra-Orthographe is available into the "abracadabraTools" sub-menu and as a Quicktool icon
// abracadabraTools-Orthographe runs with Acrobat Reader, Acrobat Pro and Acrobat Standard, version X(10) or +
//
// abracadabraTools DC is a set of free utilities created by abracadabraPDF.net
// abracadabraTools DC adds many useful functions into Adobe Acrobat Pro DC
// abracadabraTools DC runs with MacOS and Windows
// Copyrights - JR Boulay - 2002-2020 - https://www.abracadabrapdf.net/contact/
// Support & assistance : https://abracadabrapdf.net/forum/index.php/board,15.0.html
//
////////////////////////---FRANÇAIS---////////////////////////
//
// abracadabraTools-Orthographe vérifie l'orthographe de tous les mots du document
// abracadabra-Orthographe est disponible dans le menu "abracadabraTools" et comme icône d'outil rapide
// abracadabraTools-Orthographe fonctionne avec Acrobat Reader, Acrobat Pro et Acrobat Standard, version X(10) ou +
//
// abracadabraTools DC est un ensemble d'utilitaires gratuits offert par abracadabraPDF.net
// abracadabraTools DC ajoute des fonctions utiles dans le logiciel Adobe Acrobat Pro DC
// abracadabraTools DC fonctionne sur systèmes MacOS et Windows
// Tous droits réservés - JR Boulay - 2002-2020 - https://www.abracadabrapdf.net/contact/
// Support & assistance : https://abracadabrapdf.net/forum/index.php/board,15.0.html
//
////////////////////////////////////////////////////////////////////////////////////////////////////
//
if (typeof app.formsVersion != "undefined" && app.formsVersion >= 9) {
	var strTitreId = "abracadabraTools DC";
	var idStrSpell4 = "";
	if (app.language == "FRA") {
		var idStrSpell0 = "V\u00C9RIFIER L'ORTHOGRAPHE\r\r\r"; // en-tête pour les alertes
		var idStrSpell1 = "V\u00E9rifier l'orthographe"; // pour bouton
		var idStrSpell1m = "Orthographe"; // pour menu (qui ne supporte pas les caractères accentués même en Unicode)
		var idStrSpell2 = "V\u00E9rifier l'orthographe dans toutes les pages";
		var idStrSpell3 = " "; // avec espace (français)
		var idStrSpell4a = " mot suspect a \u00E9t\u00E9 d\u00E9tect\u00E9.\rIl est signal\u00E9 dans le panneau des Commentaires.\r";
		var idStrSpell4b = " mots suspects ont \u00E9t\u00E9 d\u00E9tect\u00E9s.\rIls sont signal\u00E9s dans le panneau des Commentaires.\r";
		var idStrSpell4c = "Aucun mot suspect n'a \u00E9t\u00E9 d\u00E9tect\u00E9.\r";
		var idStrSpell5 = "Voulez-vous vraiment v\u00E9rifier l'orthographe de toutes les pages du document actif ?\r\rCette op\u00E9ration peut \u00EAtre longue s'il y a beaucoup de mots dans le document.\r";
		var idStrSpell6 = "Analyse de la page ";
	}
	else {
		var idStrSpell0 = "SPELL CHECK\r\r\r"; // en-tête pour les alertes
		var idStrSpell1 = "Spell Check"; // pour bouton
		var idStrSpell1m = "Spell Check"; // pour menu
		var idStrSpell2 = "Spell check all pages";
		var idStrSpell3 = ""; // sans espace (anglais)
		var idStrSpell4a = " suspicious word has been detected.\rIt is reported in the Comments pane.\r";
		var idStrSpell4b = " suspicious words were detected.\rThey are reported in the Comments pane.\r";
		var idStrSpell4c = "No suspicious word was detected.\r";
		var idStrSpell5 = "Do you really want to check the spelling of all the pages of the current document?\r\rThis operation can be long if there are many words in the document.\r";
		var idStrSpell6 = "Processing page ";
	}
}
//
////////////////////////////////////////////////////////////////////////////////////////////////////
if(void 0!==app.formsVersion&&app.formsVersion>=9){function lanceVerifOrtho(){if(app.beginPriv(),"undefined"==typeof bAffichAlerteOrtho&&(bAffichAlerteOrtho=!0),bAffichAlerteOrtho){var f={bInitialValue:!0,bAfterValue:!1};4==app.alert({cMsg:idStrSpell0+idStrSpell5,cTitle:strTitreId,oCheckbox:f,nIcon:2,nType:2})&&(bAffichAlerteOrtho=!f.bAfterValue,verifOrthograf(this),confirmOrtho())}else verifOrthograf(this),confirmOrtho();app.endPriv()}var myTrustedlanceVerifOrtho=app.trustedFunction(lanceVerifOrtho);function verifOrthograf(f){var e,b;comptMots=0;var t=app.thermometer;t.duration=f.numPages,t.begin();for(var r=0;r<f.numPages&&(t.value=r,t.text=idStrSpell6+(r+1),!t.cancelled);r++){b=f.getPageNumWords(r);for(var a=0;a<b;a++)if(null!=(e=spell.checkWord(f.getPageNthWord(r,a)))){comptMots+=1;var n="Suggestions"+idStrSpell3+": "+e.toString();f.addAnnot({page:r,type:"Squiggly",quads:f.getPageNthWordQuads(r,a),author:idStrSpell1,contents:n,strokeColor:["RGB",163/255,0,0],width:1})}}t.end(),t.end()}function confirmOrtho(){if(app.beginPriv(),comptMots>1?idStrSpell4=idStrSpell0+comptMots+idStrSpell4b:1==comptMots?idStrSpell4=idStrSpell0+comptMots+idStrSpell4a:0==comptMots&&(idStrSpell4=idStrSpell0+idStrSpell4c),"undefined"==typeof bAffichAlerteOrtho2&&(bAffichAlerteOrtho2=!0),bAffichAlerteOrtho2){var f={bInitialValue:!1,bAfterValue:!1};app.alert({cMsg:idStrSpell4,cTitle:strTitreId,oCheckbox:f,nIcon:3,nType:0})}else app.alert({cMsg:idStrSpell4,cTitle:strTitreId,oCheckbox:f,nIcon:3,nType:0});app.endPriv()}1!=global.aTmenu&&(app.addSubMenu({cName:"abracadabraTools \u002A",cParent:"Edit",nPos:0}),app.addMenuItem({cName:"-",cParent:"Edit",nPos:0,cEnable:!1,cExec:null}),global.aTmenu=1),app.addMenuItem({cName:idStrSpell1m,cParent:"abracadabraTools \u002A",nPos:0,cExec:"myTrustedlanceVerifOrtho(lanceVerifOrtho)",cEnable:"event.rc = (event.target != null)"});var strIconVerifOrtho="ffffffffffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffffffffffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffb40000ffb40000ffb40000ffffffffffffffffffb40000ffb40000ffb40000ffffffffffffffffffb40000ffb40000ff00ac00ffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffb40000ffffffffffb40000ffffffffffffffffffb40000ffffffffffb40000ffffffffffb40000ffffffffff00ac00ffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffb40000ffffffffffb40000ffffffffffffffffffb40000ffffffffffb40000ffffffffffb40000ff00ac00ffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffb40000ffb40000ffb40000ffffffffff00ac00ffb40000ffb40000ffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00ac00ffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffff00ac00ff00ac00ffffffffffffffffff00ac00ffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffff00ac00ffffffffff00ac00ff00ac00ffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffff00ac00ff00ac00ff00ac00ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00ac00ff00ac00ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00ac00ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffffffffffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffffffff",oIconVerifOrtho={count:0,width:20,height:20,read:function(f){return strIconVerifOrtho.slice(this.count,this.count+=f)}},verifOrthoBouton={cName:"verifOrtho",cExec:"myTrustedlanceVerifOrtho(lanceVerifOrtho)",cEnable:"event.rc = event.target != null",cMarked:"event.rc = false",cTooltext:idStrSpell2,oIcon:oIconVerifOrtho,cLabel:idStrSpell1};try{app.removeToolButton("verifOrtho")}catch(f){}try{app.addToolButton(verifOrthoBouton)}catch(f){}if(1!=global.aTmenAide){if("FRA"==app.language)var strMenAide00="abracadabraTools",strMenAide01="Support & assistance...",strMenAide02="Actualisation...",strMenAide03="https://www.abracadabrapdf.net/?p=111",strMenAide04="Site web",strMenAide05="https://www.abracadabrapdf.net/";else strMenAide00="abracadabraTools",strMenAide01="Support & Assistance...",strMenAide02="Check for update...",strMenAide03="https://www.abracadabrapdf.net/?p=972",strMenAide04="Web Site",strMenAide05="https://www.abracadabrapdf.net/?p=1591";app.addMenuItem({cName:"-",cParent:"Help",nPos:21,cEnable:!1,cExec:null}),app.addSubMenu({cName:strMenAide00,cParent:"Help",nPos:22}),app.addMenuItem({cName:strMenAide04,cParent:strMenAide00,nPos:0,cExec:"app.launchURL(strMenAide05);"}),app.addMenuItem({cName:strMenAide02,cParent:strMenAide00,nPos:1,cExec:"app.launchURL(strMenAide03);"}),app.addMenuItem({cName:strMenAide01,cParent:strMenAide00,nPos:2,cExec:"app.launchURL('https://abracadabrapdf.net/forum/');"}),global.aTmenAide=1}}
////////////////////////////////////////////////////////////////////////////////////////////////////