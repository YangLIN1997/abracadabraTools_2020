////////////////////////////////////////////////////////////////////////////////////////////////////
//
// abracadabraTools DC - Recadrer sur zone de rognage / Crop to TrimBox
// Version 2020-02-20
//
////////////////////////---ENGLISH---////////////////////////
//
// abracadabraTools-Recadrage Crops all pages in the current document (removing the bleebox and all printmarks)
// abracadabraTools-Recadrage is available into the Edit:abracadabraTools menu and as a Quicktool icon
// abracadabraTools-Recadrage requires Acrobat Pro or Acrobat Standard, version X(10) or +
//
// abracadabraTools DC is a set of free utilities created by abracadabraPDF.net
// abracadabraTools DC adds many useful functions into Adobe Acrobat DC
// abracadabraTools DC runs with Mac OS and Windows
// Copyrights - JR Boulay - 2002-2020 - https://www.abracadabrapdf.net/contact/
// Support & assistance : https://abracadabrapdf.net/forum/index.php/board,15.0.html
//
////////////////////////---FRANÇAIS---////////////////////////
//
// abracadabraTools-Recadrage Recadre toutes les pages du document actif sur la zone de rognage (ce qui supprime les fonds perdus et les traits de coupe)
// abracadabraTools-Recadrage est disponible dans le menu Edition:abracadabraTools et comme icône d'outil rapide
// abracadabraTools-Recadrage requiert Acrobat Pro ou Acrobat Standard, version X(10) ou +
//
// abracadabraTools DC est un ensemble d'utilitaires gratuits offert par abracadabraPDF.net
// abracadabraTools DC ajoute des fonctions utiles dans le logiciel Adobe Acrobat DC
// abracadabraTools DC fonctionne sur systèmes Mac OS et Windows
// Tous droits réservés - JR Boulay - 2002-2020 - https://www.abracadabrapdf.net/contact/
// Support & assistance : https://abracadabrapdf.net/forum/index.php/board,15.0.html
//
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
//
if (typeof app.formsVersion != "undefined" && app.formsVersion > 9 && app.viewerVariation != "Reader") {
	var strTitreId = "abracadabraTools DC";
	if (app.language == "FRA") {
		var crop10 = "Recadrer";
		var crop11 = "Recadrer sur zone de rognage";
		var crop12 = "Recadrer sur zone de rognage, ce qui supprime les fonds perdus et les rep\u00E8res d'impression";
		var crop13 = "RECADRER SUR ZONE DE ROGNAGE\r\r\rVoulez-vous vraiment recadrer toutes les pages de ce document, c'est-\u00E0-dire supprimer les fonds perdus et les rep\u00E8res d'impression ?\r\rCette op\u00E9ration ne pourra pas \u00EAtre annul\u00E9e.\rSi besoin utilisez : menu Fichier : R\u00E9tablir.\r";
	}
	else {	
		var crop10 = "Crop";
		var crop11 = "Crop to TrimBox";
		var crop12 = "Crop to TrimBox, to remove bleedbox and printmarks";
		var crop13 = "CROP TO TRIMBOX\r\r\rDo you really want to crop all pages, removing bleedbox and printmarks?\r\rThis action cannot be canceled.\rIf necessary use : File menu : Revert.\r";
	}
}
//
////////////////////////////////////////////////////////////////////////////////////////////////////
if(void 0!==app.formsVersion&&app.formsVersion>9&&"Reader"!=app.viewerVariation){var strNomMenu="abracadabraTools \u002A";1!=global.aTmenu&&(app.addSubMenu({cName:strNomMenu,cParent:"Edit",nPos:0}),app.addMenuItem({cName:"-",cParent:"Edit",nPos:0,cEnable:!1,cExec:null}),global.aTmenu=1),app.addMenuItem({cName:crop11,cParent:strNomMenu,nPos:0,cEnable:"event.rc = event.target != null",cExec:"myTrustedcropDoc(crop)"});var strIconRecadragBouton="ffffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffa2000affa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affa2000affffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffa2000affa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affa2000affffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffff",oIconRecadragBouton={count:0,width:20,height:20,read:function(f){return strIconRecadragBouton.slice(this.count,this.count+=f)}},recadragBouton={cName:"recadrag",cExec:"myTrustedcropDoc(crop)",cEnable:"event.rc = event.target != null",cMarked:"event.rc = false",cTooltext:crop12,oIcon:oIconRecadragBouton,cLabel:crop10};try{app.removeToolButton("recadrag")}catch(f){}try{app.addToolButton(recadragBouton)}catch(f){}function crop(){app.beginPriv();try{if("undefined"==typeof bAffichAlerteCrop&&(bAffichAlerteCrop=!0),bAffichAlerteCrop){var f={bInitialValue:!0,bAfterValue:!1};if(4==app.alert({cMsg:crop13,cTitle:strTitreId,oCheckbox:f,nIcon:2,nType:2})){bAffichAlerteCrop=!f.bAfterValue;var a=this.numPages;a-=1;for(var e=0;e<=a;e++){var t=this.getPageBox("Trim",e);this.setPageBoxes({cBox:"Crop",nStart:e,nEnd:e,rBox:t})}app.beep(),this.zoomType=zoomtype.fitP}}else{a=this.numPages;a-=1;for(e=0;e<=a;e++){t=this.getPageBox("Trim",e);this.setPageBoxes({cBox:"Crop",nStart:e,nEnd:e,rBox:t})}app.beep(),this.zoomType=zoomtype.fitP}}catch(f){console.println(f),console.show()}app.endPriv()}var myTrustedcropDoc=app.trustedFunction(crop);if(1!=global.aTmenAide){if("FRA"==app.language)var strMenAide00="abracadabraTools",strMenAide01="Support & assistance...",strMenAide02="Actualisation...",strMenAide03="https://www.abracadabrapdf.net/?p=111",strMenAide04="Site web",strMenAide05="https://www.abracadabrapdf.net/";else strMenAide00="abracadabraTools",strMenAide01="Support & Assistance...",strMenAide02="Check for update...",strMenAide03="https://www.abracadabrapdf.net/?p=972",strMenAide04="Web Site",strMenAide05="https://www.abracadabrapdf.net/?p=1591";app.addMenuItem({cName:"-",cParent:"Help",nPos:21,cEnable:!1,cExec:null}),app.addSubMenu({cName:strMenAide00,cParent:"Help",nPos:22}),app.addMenuItem({cName:strMenAide04,cParent:strMenAide00,nPos:0,cExec:"app.launchURL(strMenAide05);"}),app.addMenuItem({cName:strMenAide02,cParent:strMenAide00,nPos:1,cExec:"app.launchURL(strMenAide03);"}),app.addMenuItem({cName:strMenAide01,cParent:strMenAide00,nPos:2,cExec:"app.launchURL('https://abracadabrapdf.net/forum/');"}),global.aTmenAide=1}}
////////////////////////////////////////////////////////////////////////////////////////////////////
