////////////////////////////////////////////////////////////////////////////////////////////////////
//
// abracadabraTools DC - Supprimer les pages sans commentaires / Delete pages without comments
// Version 2020-02-20
//
////////////////////////---ENGLISH---////////////////////////
//
// abracadabraTools-DPWC deletes all pages without comments in the current document
// abracadabraTools-DPWC is available into the Edit:abracadabraTools menu and as a Quicktool icon
// abracadabraTools-DPWC requires Acrobat Pro or Acrobat Standard, version X(10) or +
//
// abracadabraTools DC is a set of free utilities created by abracadabraPDF.net
// abracadabraTools DC adds many useful functions into Adobe Acrobat Pro DC
// abracadabraTools DC runs with Mac OS and Windows
// Copyrights - JR Boulay - 2002-2020 - https://www.abracadabrapdf.net/contact/
// Support & assistance : https://abracadabrapdf.net/forum/index.php/board,15.0.html
//
////////////////////////---FRANÇAIS---////////////////////////
//
// abracadabraTools-SPSC supprime toutes les pages sans commentaires du document actif
// abracadabraTools-SPSC est disponible dans le menu Edition:abracadabraTools et comme icône d'outil rapide
// abracadabraTools-SPSC requiert Acrobat Pro ou Acrobat Standard, version X(10) ou +
//
// abracadabraTools DC est un ensemble d'utilitaires gratuits offert par abracadabraPDF.net
// abracadabraTools DC ajoute des fonctions utiles dans le logiciel Adobe Acrobat Pro DC
// abracadabraTools DC fonctionne sur systèmes Mac OS et Windows
// Tous droits réservés - JR Boulay - 2002-2020 - https://www.abracadabrapdf.net/contact/
// Support & assistance : https://abracadabrapdf.net/forum/index.php/board,15.0.html
//
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
//
if (typeof app.formsVersion != "undefined" && app.formsVersion > 9 && app.viewerVariation != "Reader") {
	var strTitreId = "abracadabraTools DC";
	if (app.language == "FRA") {
		var abraDel = "Supprimer les pages sans commentaires"; // pour menu
		var abraDelb = "SPSC"; // pour bouton
		var abraDel2 = "Supprimer les pages sans commentaires";
		var abraDel3 = "SUPPRIMER LES PAGES SANS COMMENTAIRES\r\r\r"; // en-tête pour les alertes
		var abraDel01 = abraDel3 + "Aucun commentaire n'a \u00E9t\u00E9 d\u00E9tect\u00E9 dans ce document.\rAucune page n'a \u00E9t\u00E9 supprim\u00E9e.\r";
		var abraDel02 = " page(s) supprim\u00E9e(s). ";
		var abraDel03 = " page(s) conserv\u00E9e(s). ";
		var abraDel04 = "\r\rEnregistrez une copie ce document pour conserver l'original intact.\r";
		var abraDel05 = abraDel3 + "Voulez-vous vraiment supprimer de ce document toutes les pages qui ne contiennent pas de commentaire ou d'annotation ?\r\rCette op\u00E9ration ne pourra pas \u00EAtre annul\u00E9e.\rSi besoin utilisez : menu Fichier : R\u00E9tablir.\r";
	}
	else {	
		var abraDel = "Delete pages without comments"; // pour menu
		var abraDelb = "DPWC"; // pour bouton
		var abraDel2 = "Delete pages without comments";
		var abraDel3 = "DELETE PAGES WITHOUT COMMENTS\r\r\r"; // en-tête pour les alertes
		var abraDel01 = abraDel3 + "No comment have been detected in this document.\rNo pages have been deleted.\r";
		var abraDel02 = " page(s) deleted. ";
		var abraDel03 = " page(s) kept. ";
		var abraDel04 = "\r\rSave this document as a copy to leave the original untouched.\r";
		var abraDel05 = abraDel3 + "Do you really want to remove from this document all pages that do not contain comment or annotation?\r\rThis action cannot be canceled.\rIf necessary use : File menu : Revert.\r";
	}
}
//
////////////////////////////////////////////////////////////////////////////////////////////////////
if(void 0!==app.formsVersion&&app.formsVersion>9&&"Reader"!=app.viewerVariation){var strNomMenu="abracadabraTools \u002A";1!=global.aTmenu&&(app.addSubMenu({cName:strNomMenu,cParent:"Edit",nPos:0}),app.addMenuItem({cName:"-",cParent:"Edit",nPos:0,cEnable:!1,cExec:null}),global.aTmenu=1),app.addMenuItem({cName:abraDel,cParent:strNomMenu,nPos:0,cEnable:"event.rc = event.target != null",cExec:"myTrustedDelNoCom(delNoComPages)"});var strIconNoCommentBouton="ffffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffffffffffffffffffa2000affffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffffffa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affa2000affffffff",oIconNoCommentBouton={count:0,width:20,height:20,read:function(f){return strIconNoCommentBouton.slice(this.count,this.count+=f)}},noComBouton={cName:"NoComment",cExec:"myTrustedDelNoCom(delNoComPages)",cEnable:"event.rc = event.target != null",cMarked:"event.rc = false",cTooltext:abraDel2,oIcon:oIconNoCommentBouton,cLabel:abraDelb};try{app.removeToolButton("NoComment")}catch(f){}try{app.addToolButton(noComBouton)}catch(f){}function delNoComPages(){app.beginPriv();var f=0;if("undefined"==typeof bAffichAlerteSPSC&&(bAffichAlerteSPSC=!0),bAffichAlerteSPSC){var a={bInitialValue:!0,bAfterValue:!1};if(4==app.alert({cMsg:abraDel05,cTitle:strTitreId,oCheckbox:a,nIcon:2,nType:2})){bAffichAlerteSPSC=!a.bAfterValue;f=1}}else f=1;if(1==f){var e=0,t=0;if(this.syncAnnotScan(),null!=this.getAnnots()){for(var n=this.numPages-1;n>=0;n--){null==this.getAnnots({nPage:n})?(this.deletePages({nStart:n,nEnd:n}),e++):t++}app.alert({cMsg:abraDel3+e+abraDel02+"\r"+t+abraDel03+abraDel04+"\r",cTitle:strTitreId,nIcon:3})}else app.alert({cMsg:abraDel01,cTitle:strTitreId,nIcon:3})}app.endPriv()}var myTrustedDelNoCom=app.trustedFunction(delNoComPages);if(1!=global.aTmenAide){if("FRA"==app.language)var strMenAide00="abracadabraTools",strMenAide01="Support & assistance...",strMenAide02="Actualisation...",strMenAide03="https://www.abracadabrapdf.net/?p=111",strMenAide04="Site web",strMenAide05="https://www.abracadabrapdf.net/";else strMenAide00="abracadabraTools",strMenAide01="Support & Assistance...",strMenAide02="Check for update...",strMenAide03="https://www.abracadabrapdf.net/?p=972",strMenAide04="Web Site",strMenAide05="https://www.abracadabrapdf.net/?p=1591";app.addMenuItem({cName:"-",cParent:"Help",nPos:21,cEnable:!1,cExec:null}),app.addSubMenu({cName:strMenAide00,cParent:"Help",nPos:22}),app.addMenuItem({cName:strMenAide04,cParent:strMenAide00,nPos:0,cExec:"app.launchURL(strMenAide05);"}),app.addMenuItem({cName:strMenAide02,cParent:strMenAide00,nPos:1,cExec:"app.launchURL(strMenAide03);"}),app.addMenuItem({cName:strMenAide01,cParent:strMenAide00,nPos:2,cExec:"app.launchURL('https://abracadabrapdf.net/forum/');"}),global.aTmenAide=1}}
////////////////////////////////////////////////////////////////////////////////////////////////////
