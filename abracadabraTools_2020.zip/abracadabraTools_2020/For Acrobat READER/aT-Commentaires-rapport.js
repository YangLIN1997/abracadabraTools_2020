////////////////////////////////////////////////////////////////////////////////////////////////////
//
// abracadabraTools DC - Comments report - Lister les commentaires
// Version 2020-02-20
//
////////////////////////---ENGLISH---////////////////////////
//
// abracadabraTools-Comments-report report all comments of the current PDF file in the JavaScript Console
// abracadabraTools-Comments-report is available into the Edit:abracadabraTools menu and as a Quicktool icon
// abracadabraTools-Comments-report runs with Acrobat Reader, version X(10) or +
// (Acrobat Pro and Acrobat Standard provide a more complete function)
//
// abracadabraTools DC is a set of free utilities created by abracadabraPDF.net
// abracadabraTools DC adds many useful functions into Adobe Acrobat DC
// abracadabraTools DC runs with Mac OS and Windows
// Copyrights - JR Boulay - 2002-2020 - https://www.abracadabrapdf.net/contact/
// Support & assistance : https://abracadabrapdf.net/forum/index.php/board,15.0.html
//
////////////////////////---FRANÇAIS---////////////////////////
//
// abracadabraTools-Commentaires-rapport affiche la liste des commentaires du document PDF actif dans la Console JavaScript
// abracadabraTools-Commentaires-rapport est disponible dans le menu Edition:abracadabraTools et comme icône d'outil rapide
// abracadabraTools-Commentaires-rapport fonctionne avec Acrobat Reader, version X(10) ou +
// (Acrobat Pro et Acrobat Standard offrent une fonction plus complète)
//
// abracadabraTools DC est un ensemble d'utilitaires gratuits offert par abracadabraPDF.net
// abracadabraTools DC ajoute des fonctions utiles dans le logiciel Adobe Acrobat DC
// abracadabraTools DC fonctionne sur systèmes Mac OS et Windows
// Tous droits réservés - JR Boulay - 2002-2020 - https://www.abracadabrapdf.net/contact/
// Support & assistance : https://abracadabrapdf.net/forum/index.php/board,15.0.html
//
////////////////////////////////////////////////////////////////////////////////////////////////////
//
if (app.viewerVariation == "Reader" && app.formsVersion > 9) {
	if (app.language == "FRA") {
		var strRapComment00 = "Lister tous les commentaires du document dans la Console"; // tooltip bouton
		var strRapComment01 = "Lister les commentaires..."; // menu
		var strRapComment01b = "Commentaires liste"; // bouton
		var strRapComment02 = "Choisir un mode de classement";
		// var strRapComment03 = "Aucun";
		var strRapComment04 = "Page";
		var strRapComment05 = "Auteur";
		var strRapComment06 = "Date";
		var strRapComment07 = "Type";
		var strRapComment08 = "LISTE DES COMMENTAIRES DU DOCUMENT : ";
		var strRapComment09 = "Aucun commentaire n'a \u00E9t\u00E9 d\u00E9tect\u00E9 dans ce document";
	}
	else {
		var strRapComment00 = "Report all document comments in the Console"; // tooltip bouton
		var strRapComment01 = "Comments Report..."; // menu
		var strRapComment01b = "Comments Report"; // bouton
		var strRapComment02 = "Select a sort type";
		// var strRapComment03 = "None";
		var strRapComment04 = "Page";
		var strRapComment05 = "Author";
		var strRapComment06 = "Date";
		var strRapComment07 = "Type";
		var strRapComment08 = "LIST OF COMMENTS FOR DOCUMENT:";
		var strRapComment09 = "No comments were detected in this document";
		}
}
//
////////////////////////////////////////////////////////////////////////////////////////////////////
if("Reader"==app.viewerVariation&&app.formsVersion>9){var strNomMenu="abracadabraTools \u002A";1!=global.aTmenu&&(app.addSubMenu({cName:strNomMenu,cParent:"Edit",nPos:0}),app.addMenuItem({cName:"-",cParent:"Edit",nPos:0,cEnable:!1,cExec:null}),global.aTmenu=1),app.addMenuItem({cName:"Commentaires_rapport",cUser:strRapComment01,cParent:strNomMenu,cExec:"listeDesComments(this)",nPos:0,cEnable:"event.rc = app.doc;"}),listeDesComments=app.trustedFunction(function(f){var b=[];b.push({cName:strRapComment02,bEnabled:!1}),b.push({cName:"-"}),b.push({cName:strRapComment04,cReturn:ANSB_Page}),b.push({cName:strRapComment05,cReturn:ANSB_Author}),b.push({cName:strRapComment06,cReturn:ANSB_ModDate}),b.push({cName:strRapComment07,cReturn:ANSB_Type});var e=app.popUpMenuEx.apply(app,b)||ANSB_None;f.syncAnnotScan();var t=f.getAnnots({nSortBy:e,bReverse:!1});if(t){console.clear(),console.show(),console.println(strRapComment08+this.documentFileName+"\r\r\r");for(var a=0;a<t.length;a++)console.println(util.printf("Page %s par %s le %s",1+t[a].page,t[a].author,util.printd("yyyy/mm/dd HH:MM:ss",t[a].creationDate))),console.println(t[a].contents+"\r\r")}else console.clear(),console.show(),console.println(strRapComment08+this.documentFileName+"]\r\r"),console.println(strRapComment09)});var strIconComReport="ffffffffffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffffffffffffffffffb40000ffb40000ffb40000ffb40000ffb40000ffffffffffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffb40000ffffffffffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffffffffffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffffffffffb40000ffb40000ffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffffffffffffffffffb40000ffb40000ffffffffffb40000ffb40000ffffffffffffffffffffffffffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffffffffffffffffffffffffffb40000ffffffffffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffffffffffb40000ffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffffffffffffffffffffffffffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffb40000ffffffffffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffffffffffb40000ffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffb40000ffffffffffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffffffffffb40000ffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffffffffffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffb40000ffffffff",oIconComReport={count:0,width:20,height:20,read:function(f){return strIconComReport.slice(this.count,this.count+=f)}},comReportBouton={cName:"Commentaires-rapport",cExec:"listeDesComments(this)",cEnable:"event.rc = event.target != null",cMarked:"event.rc = false",cTooltext:strRapComment00,oIcon:oIconComReport,cLabel:strRapComment01b};try{app.removeToolButton("comReport")}catch(f){}try{app.addToolButton(comReportBouton)}catch(f){}if(1!=global.aTmenAide){if("FRA"==app.language)var strMenAide00="abracadabraTools",strMenAide01="Support & assistance...",strMenAide02="Actualisation...",strMenAide03="https://www.abracadabrapdf.net/?p=111",strMenAide04="Site web",strMenAide05="https://www.abracadabrapdf.net/";else strMenAide00="abracadabraTools",strMenAide01="Support & Assistance...",strMenAide02="Check for update...",strMenAide03="https://www.abracadabrapdf.net/?p=972",strMenAide04="Web Site",strMenAide05="https://www.abracadabrapdf.net/?p=1591";app.addMenuItem({cName:"-",cParent:"Help",nPos:21,cEnable:!1,cExec:null}),app.addSubMenu({cName:strMenAide00,cParent:"Help",nPos:22}),app.addMenuItem({cName:strMenAide04,cParent:strMenAide00,nPos:0,cExec:"app.launchURL(strMenAide05);"}),app.addMenuItem({cName:strMenAide02,cParent:strMenAide00,nPos:1,cExec:"app.launchURL(strMenAide03);"}),app.addMenuItem({cName:strMenAide01,cParent:strMenAide00,nPos:2,cExec:"app.launchURL('https://abracadabrapdf.net/forum/');"}),global.aTmenAide=1}}
////////////////////////////////////////////////////////////////////////////////////////////////////
