////////////////////////////////////////////////////////////////////////////////////////////////////
//
// abracadabraTools DC - Réinitialiser un formulaire / Reset form
// Version 2020-02-20
//
////////////////////////---ENGLISH---////////////////////////
//
// abracadabraTools-ResetForm resets all form fields
// abracadabraTools-ResetForm is available into the Edit:abracadabraTools menu
// abracadabraTools-ResetForm requires Acrobat Reader, version X(10) or +
//
// abracadabraTools DC is a set of free utilities created by abracadabraPDF.net
// abracadabraTools DC adds many useful functions into Adobe Acrobat DC
// abracadabraTools DC runs with Mac OS and Windows
// Copyrights - JR Boulay - 2002-2020 - https://www.abracadabrapdf.net/contact/
// Support & assistance : https://abracadabrapdf.net/forum/index.php/board,15.0.html
//
////////////////////////---FRANÇAIS---////////////////////////
//
// abracadabraTools-ResetForm réinitialise tous les champs de formulaire
// abracadabraTools-ResetForm est disponible dans le menu Edition:abracadabraTools
// abracadabraTools-ResetForm requiert Acrobat Reader, version X(10) ou +
//
// abracadabraTools DC est un ensemble d'utilitaires gratuits offert par abracadabraPDF.net
// abracadabraTools DC ajoute des fonctions utiles dans le logiciel Adobe Acrobat DC
// abracadabraTools DC fonctionne sur systèmes Mac OS et Windows
// Tous droits réservés - JR Boulay - 2002-2020 - https://www.abracadabrapdf.net/contact/
// Support & assistance : https://abracadabrapdf.net/forum/index.php/board,15.0.html
//
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
if(void 0!==app.formsVersion&&app.formsVersion>6&&"Reader"==app.viewerVariation){if("FRA"==app.language)var cMessAlert="R\u00C9INITIALISER LE FORMULAIRE\n\n\nVoulez vous vraiment supprimer le contenu de tous les champs de donn\u00E9es et revenir \u00E0 l'\u00E9tat initial du document ?\n\nCette action ne pourra pas \u00EAtre annul\u00E9e.",cMessTitre="abracadabraTools",cTxtMenu1="R\u00E9initialiser le formulaire",cTxtMenu2="R\u00E9initialiser les champs du formulaire";else cMessAlert="CLEAR FORM\n\n\nReset all form fields?\rThis action cannot be undone. OK to continue?\r",cMessTitre="abracadabraTools",cTxtMenu1="Clear Form",cTxtMenu2="Reset all form fields";function customReset(){try{if("undefined"==typeof bClearDialog&&(bClearDialog=!0),bClearDialog){var e={bInitialValue:!1,bAfterValue:!1};4==app.alert({cMsg:cMessAlert,cTitle:cMessTitre,oCheckbox:e,nIcon:2,nType:2})&&(bClearDialog=!e.bAfterValue,resetDoc())}else this.resetForm()}catch(e){console.println(e)}}app.addMenuItem({cName:cTxtMenu1,cUser:cTxtMenu2,cParent:"Edit",cExec:"customReset();",cEnable:"event.rc = (event.target != null);"})}
////////////////////////////////////////////////////////////////////////////////////////////////////

